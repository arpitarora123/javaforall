/**
 * 
 */
package com.practice.interview.redhat.webservice;

/**
 * Address class.
 * 
 * @author Arpit
 * @version 1.0
 * @since 2019-02-15
 */
public class Address {
	String street1;
	String street2;
	String state;
}